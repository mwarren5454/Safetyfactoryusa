Safety Factory USA Autopilot Starter Package

Start here:
1. Open docs/SafetyFactoryUSA_Setup_Guide.docx
2. Upload the contents of /site to GitHub Pages.
3. Use /downloadable_templates_docx for editable source templates.

This is a starter package, not legal advice. Adapt all forms and content to the specific facility and current regulatory requirements.
